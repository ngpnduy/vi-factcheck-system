# M0/M1/M2 pilot results - completed 4 October 2026

Open REPORT.html in any browser to read the finished report. It works offline.
Open results/results.csv in Excel for the summary comparison.

## Study

900 stratified training claims (300 per label), seed 42, full 723-claim validation
split, full 1,447-claim test split. Fixed LR 2e-5 and evidence lambda 0.5; no tuning.
This is a reduced-data single-seed pilot, not the full proposal experiment.
All three models completed training, evaluation, checkpoint reload and raw-text
prediction consistency checks. Workflow elapsed time was about 4 hours 5 minutes.

| Model | Test Macro-F1 | Test accuracy |
|---|---:|---:|
| M0 | 51.01% | 51.69% |
| M1 | 52.48% | 54.11% |
| M2 | 54.84% | 56.46% |

M2 improved aggregate performance but REFUTED F1 decreased relative to M1.
Read the full report for per-label scores, evidence coverage, uncertainty,
resource measurements, examples and limitations.

## Contents

- REPORT.html: browser-readable complete report.
- results/REPORT.md: original finished Markdown report.
- results/results.csv: summary scores, retrieval metrics, runtime and memory.
- results/*_test_metrics.json and *_dev_metrics.json: full metrics.
- results/*_test_predictions.jsonl and *_dev_predictions.jsonl: per-claim output,
  including selected sentences and evidence weights. JSONL has one object per line.
- results/*_example_prediction.json: raw-text prediction examples.
- results/paired_bootstrap.json: paired article-cluster confidence intervals.
- results/experiment.json and pilot_spec.json: settings, exact sampled claim IDs,
  pinned revisions, data checksums and source hashes.
- results/*_history.json and *_checks.json: epoch histories and behavioral checks.
- results/completion.json: completion and test-artifact checksums.
- code/rush/: matching implementation, tests, setup guide and original proposal.
- ARCHIVE_MANIFEST.json: SHA256 and size for every payload entry.

## Source and reproduction

Source commit: d8416b9753eb000e55dea4d69f4c614ae4920e32
GitHub branch: https://github.com/ngpnduy/vi-factcheck-system/tree/Rush-version
Pinned code: https://github.com/ngpnduy/vi-factcheck-system/tree/d8416b9753eb000e55dea4d69f4c614ae4920e32/rush

See code/rush/README.md for environment setup and prepare/train/tune/evaluate/
predict commands. Downloaded assets and prepared datasets are not in this archive.
The setup/provenance guides retain the historical import status; the completed
pilot results in results/ and REPORT.html supersede that earlier running status.

## Trained weights

This results archive excludes model weights. The three retained m0_best.pt,
m1_best.pt and m2_best.pt checkpoints total 2,694,887,120 bytes
(approximately 2.69 GB) and remain in the original laptop run
folder. Weights must be obtained separately to run inference from these trained
models. The source and results alone do not replace the trained parameters.

This package has not been uploaded to an external service.
